
#include <iostream>
#include <fstream>
#include <sstream>
#include <string.h>
#include <iomanip>

CODEGOLF_METHOD_PLACEHOLDER


int main(int argc, char* argv[])
{
    int i = 12;
                    std::string s = "apple";
                    double l = 3.14;
                    std::string filex = "/challenge_input/c0/input1.txt";
                    char c = 'a';
                    int count = 3;
                    
    f(i, s, l, filex, c, count);

    return 0;
}

