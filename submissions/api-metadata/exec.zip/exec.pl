#!/usr/bin/perl

sub f;

$i = 12;
$s = "apple";
$l = 3.14;
$filex = "/challenge_input/c0/input1.txt";
$c = "a";
$count = 3;

CODEGOLF_METHOD_PLACEHOLDER

        f();
        
