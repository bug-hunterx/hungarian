
<?php

$i = 12;
                    $s = "apple";
                    $l = 3.14;
                    $filex = "/challenge_input/c0/input1.txt";
                    $c = "a";
                    $count = 3;
                    
        f($i, $s, $l, $filex, $c, $count);
        
CODEGOLF_METHOD_PLACEHOLDER

?>

