
CODEGOLF_METHOD_PLACEHOLDER

local ARG0 = 12
local ARG1 = "apple"
local ARG2 = 3.14
local ARG3 = "/challenge_input/c0/input1.txt"
local ARG4 = "a"
local ARG5 = 3

f(ARG0, ARG1, ARG2, ARG3, ARG4, ARG5);

