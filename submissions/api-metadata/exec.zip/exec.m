
#import <objc/Object.h>
#import <stdio.h>
#include <stdlib.h>
#include <string.h>

CODEGOLF_METHOD_PLACEHOLDER


int main(int argc, char *argv[])
{
    int i = 12;
                    char *s = "apple";
                    double l = 3.14;
                    char *filex = "/challenge_input/c0/input1.txt";
                    char *c = "a";
                    int count = 3;
                    
    f(i, s, l, filex, c, count);

    return 0;
}

