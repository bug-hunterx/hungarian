
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.util.stream.*;
import java.util.function.*;
import java.text.*;

public class codegolf_0 {

    public static void main(String[] args) {

        int i = 12;
                    String s = "apple";
                    double l = 3.14;
                    String filex = "/challenge_input/c0/input1.txt";
                    char c = 'a';
                    int count = 3;
                    
        f(i, s, l, filex, c, count);
    }

    CODEGOLF_METHOD_PLACEHOLDER
}

