
using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;

namespace Codegolf
{
    class Program
    {
        static void Main(string[] args)
        {
            var i = 12;
                    var s = "apple";
                    var l = 3.14;
                    var filex = "/challenge_input/c0/input1.txt";
                    var c = 'a';
                    var count = 3;
                    
            f(i, s, l, filex, c, count);
        }

        CODEGOLF_METHOD_PLACEHOLDER
    }
}

