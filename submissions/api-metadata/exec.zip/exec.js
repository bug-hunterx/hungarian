
var i = parseInt(12, 10);
                    var s = "apple";
                    var l = parseFloat(3.14);
                    var filex = "/challenge_input/c0/input1.txt";
                    var c = "a";
                    var count = parseInt(3, 10);
                    
f(i, s, l, filex, c, count);

CODEGOLF_METHOD_PLACEHOLDER

